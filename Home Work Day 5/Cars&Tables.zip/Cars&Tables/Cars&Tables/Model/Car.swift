//
//  Car.swift
//  Cars&Tables
//
//  Created by Admin on 8/25/22.
//

import UIKit

struct Car {
    var image: UIImage
    var title: String
}
